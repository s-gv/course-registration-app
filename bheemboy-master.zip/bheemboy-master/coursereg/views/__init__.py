from . import faculty
from . import user
from . import light_admin
from . import misc
from . import student
